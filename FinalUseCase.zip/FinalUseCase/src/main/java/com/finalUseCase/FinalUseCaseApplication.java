package com.finalUseCase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalUseCaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinalUseCaseApplication.class, args);
	}

}
